========
PyCommit
========

PyCommit interfaces with CommitCRM using the low-level API.
It allows for both querying and updating the database,
without resorting to ODBC or the Email connector.